# Awan Prediction AI

Signal-only Android/web prototype for **two future candle direction predictions** using Deriv public market data.

## What it does
- Connects to Deriv public WebSocket market data.
- Loads recent tick history.
- Builds 1-minute or 5-minute candles.
- Shows live candlesticks and price.
- Produces two directional signals:
  - Next candle (+1): GREEN or RED
  - Following candle (+2): GREEN or RED
- Uses an experimental feature ensemble (EMA trend, RSI, short momentum).
- Displays model confidence and sample count.

## Important
The confidence number is NOT a guaranteed probability and the prototype does not claim 98%/100% accuracy. Real accuracy must be measured using walk-forward out-of-sample testing. This build does not place trades.

## Run immediately
Open `index.html` in a modern browser with internet access. It connects to the public Deriv market-data WebSocket.

## Android APK
The `index.html` is intentionally self-contained so it can be wrapped in an Android WebView/Capacitor app. Build/signing requires an Android SDK/Gradle environment (Android Studio can import the web assets).

## Data source
Deriv documents public WebSocket market-data endpoints for active symbols, tick streams, and historical tick data. See https://developers.deriv.com/docs/data/ticks/ and https://developers.deriv.com/docs/data/ticks-history/ .
